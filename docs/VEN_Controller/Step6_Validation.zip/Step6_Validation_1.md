# Step 6 — Validation & Issue Identification (Pass 2): VEN Controller (HEMS)

**Scope:** Single-site residential Home Energy Management System acting as OpenADR 3.1 VEN.  
**Version:** Draft 2 (fresh pass after all Draft 1 fixes applied)  
**Prerequisite:** Steps 1–5 (all at latest drafts)

---

## Overview

Second validation pass. All 30 issues from Draft 1 have been resolved (V-23 deferred).
This pass checks for issues INTRODUCED by the fixes, plus anything missed in Pass 1.

```
Severity levels:
  CRITICAL    — algorithm produces wrong results or entity model is structurally broken
  DESIGN_GAP  — a capability is mentioned but not fully specified
  STALE       — a document section contradicts changes made in another document
  EDGE_CASE   — behavior is unspecified for a reachable scenario
  MINOR       — naming, clarity, or consistency issue
```

---

## 1. Algorithm Issues

### W-01: FLEXIBLE Slot EffectiveCost — Used but Never Computed [CRITICAL]

**Affected:** Step 4 §6 (early firm-up), §11 (Phase 7)

Phase 2 only scores FIRM slots. FLEXIBLE slots are explicitly skipped. But two places
reference EffectiveCost for FLEXIBLE slots:

1. Early firm-up check in Phase 2: `coefficientOfVariation(S.EffectiveCost for S in eligibleFlexSlots)`
2. Phase 7 envelope eligibility: `eligibleRates = [S.EffectiveCost for S in eligibleFlexSlots where ...]`

Neither is computed. FLEXIBLE slots have ImportPrice and ExportPrice from RateSnapshot
(populated in Phase 1 step 3), but not a surplus-aware EffectiveCost (since surplus
availability in the far horizon is speculative).

```
Resolution needed: define EffectiveCost for FLEXIBLE slots.
  Simplest: EffectiveCost_FLEX = S.ImportPrice + (S.CO2Rate × CO2Weight)
  (Assume grid import for far horizon. Surplus is too uncertain to forecast.)
  Add computation in Phase 1 step 3 for FLEXIBLE slots only.
  Or: precompute a slot-level GridEffectiveCost on all slots in Phase 1,
  and use it for FLEXIBLE scoring/envelopes. Phase 2's per-packet surplus-aware
  cost is only for FIRM slots.
```


### W-02: Phase 4 EffectiveCost Ambiguity [CRITICAL]

**Affected:** Step 4 §8.1

Phase 4 ProfitablePairs check: `expensive.EffectiveCost > cheap.EffectiveCost / Efficiency`.
Since the surplus pricing change, EffectiveCost is per-packet. For storage profitability,
there is no packet context — the battery is evaluating slot-level price arbitrage.

```
Resolution needed: Phase 4 should use slot-level GridEffectiveCost
  (ImportPrice + CO2 × Weight) for profitability tests, not per-packet EffectiveCost.
  Charge from surplus: ChargeCost = ExportPrice (already handled).
  Discharge displaces grid import: DischargeValue = GridEffectiveCost of expensive slot.
```


### W-03: Phase 4 Does Not Update slotRemainingSurplus [CRITICAL]

**Affected:** Step 4 §8.2

Phase 4 charges batteries from surplus using `slotRemainingSurplus[CheapSlot]` to check
availability. But it never decrements `slotRemainingSurplus` when the battery actually
charges. Phase 5 (Residual PV Surplus) then sees surplus that the battery already claimed.

```
Resolution needed: after battery charge allocation from surplus:
  slotRemainingSurplus[chargeSlot] -= chargePower
  (Same pattern as Phase 3.)
```


### W-04: Dispatcher AccumulatedCost Not Surplus-Aware [DESIGN_GAP]

**Affected:** Step 2 §2.4, Step 3 §3.1

Dispatcher tracks: `AccumulatedCost += ActualPower × ImportPrice × dt`.
But if the asset is consuming PV surplus, the actual cost should use ExportPrice
for the surplus portion (opportunity cost), not ImportPrice.

PacketAllocation has SurplusPower_kW and GridPower_kW split, but the Dispatcher's
reads section doesn't reference these fields, and the cost tracking formula doesn't
use them.

```
Resolution needed: Dispatcher cost tracking must split actual power into
  surplus and grid portions using the current PacketAllocation's split.
  AccumulatedCost += SurplusPower × ExportPrice × dt + GridPower × ImportPrice × dt
  AccumulatedCO2 += GridPower × CO2Rate × dt  (surplus has zero CO2)

  Dispatcher reads section should include PacketAllocation.SurplusPower/GridPower.
```


---

## 2. Cross-Document Staleness

### W-05: Step 3 Does Not Reflect New Entities and Checks [STALE]

**Affected:** Step 3 (entire document)

Step 3 was last updated for SiteMeter and SITE_RESIDUAL (Draft 4). Multiple entities
and behaviors have been added since then but Step 3 doesn't know about them:

```
Missing from Step 3:
  Entity lifecycle tables:
    - ThermalModelParams (on AssetProfile, used by Planner to recompute TargetEnergy)
    - AvailabilityWindows (on AssetForecast, used by Phase 2 eligibility)
    - MeasurementWindow / RollingAverage (on PenaltyRule, used by Monitor)
    - MinSoC (on AssetProfile, used by Phase 4)
    - SurplusAvailable_kW (on PlanTimeSlot, computed in Phase 1)
    - SurplusPower_kW / GridPower_kW (on PacketAllocation, used by Dispatcher)
    - RateEstimated flag (on PlanTimeSlot, from StaleRatePolicy)

  Producer/consumer table:
    - PacketAllocation.SurplusPower — produced by Planner, consumed by Dispatcher
    - PenaltyRule.RollingAverage — produced by Monitor
    - AssetForecast.AvailabilityWindows — produced by UpdateForecast, consumed by Phase 2

  Monitor deviation detection:
    - Step 5a (LatestStart check) not in Step 3 fast loop
    - Step 5b (StaleContinueTimeout check) not in Step 3 fast loop
    - RollingAverage computation not in Step 3 penalty check

  Medium loop:
    - Thermal TargetEnergy recomputation not mentioned
    - StaleRatePolicy handling not mentioned

  Field mutation table:
    - TargetEnergy_kWh marked as CREATE-only, but thermal assets recompute each cycle
```


### W-06: Step 3 State Machine Contradicts Monitor ABANDONED Transitions [STALE]

**Affected:** Step 3 §4 (state machine)

Step 3 state machine says:
```
SCHEDULED → ABANDONED    (Planner only)
PENDING → ABANDONED      (Planner only, if infeasible before scheduling)
```

But Step 2 Monitor now sets ABANDONED in two new checks:
- Step 5a: `LatestStart check → Status = ABANDONED` (on PENDING packets)
- Step 5b: `StaleContinue check → Status = ABANDONED` (on SCHEDULED/ACTIVE packets)

```
Resolution needed: update Step 3 state machine to include Monitor as ABANDONED source.
  PENDING → ABANDONED    (Planner OR Monitor: infeasible / LatestStart missed)
  SCHEDULED → ABANDONED  (Planner OR Monitor: infeasible / stale CONTINUE)
  ACTIVE → ABANDONED     (Monitor: stale CONTINUE with no progress for StaleContinueTimeout)
```


---

## 3. Consistency Issues

### W-07: EV PostDeadlineComfortBid Default — €0.00 vs €0.02 [MINOR]

**Affected:** Step 2 §2.2, Step 4 §15, Step 5 UC-01

Step 2 translation logic says EV default is `€0.00/kWh — free energy only`.
Step 4 worked example and all Step 5 UCs use `€0.02/kWh`.

These differ in behavior: €0.00 means literally nothing is ever eligible (all slots
have EffectiveCost > 0). €0.02 allows extremely cheap slots (e.g. curtailed PV with
ExportPrice near zero).

```
Resolution needed: pick one. €0.02 is more practical (allows near-zero-cost slots).
  Update Step 2 §2.2 default to €0.02.
```


### W-08: COOKING_STOVE Has CompletionPolicy Default but Never Gets Packets [MINOR]

**Affected:** Step 1 §1.10

CompletionPolicy defaults list includes:
`- COOKING_STOVE:   CONTINUE, high bid (meal in progress)`

But per §1.9 note and Step 2 §2.2, heuristic assets like COOKING_STOVE never get
EnergyPackets. A CompletionPolicy default for an asset that can't have packets is
meaningless.

```
Resolution needed: remove COOKING_STOVE from CompletionPolicy defaults.
  Replace with note: "COOKING_STOVE: n/a (heuristic baseline only, no packets)"
```


### W-09: Synthetic Alert Packet — Created by OpenADR IF or Planner? [MINOR]

**Affected:** Step 2 §2.1, UC-06

Step 2 event translation table: `ALERT_GRID_EMERGENCY → high-priority pseudo-EnergyPacket (via Planner)`
Step 2 Alert Handling section: the alert creates a synthetic packet (in the alert handler).
UC-06: "OpenADR IF creates synthetic EnergyPacket".

Three different answers. The translation table says "via Planner", suggesting OpenADR IF
emits PlanTrigger.ALERT and the Planner creates the packet. But UC-06 says OpenADR IF
creates it directly.

```
Resolution needed: clarify ownership.
  Option A: OpenADR IF creates packet + emits PlanTrigger.ALERT. Planner plans it.
  Option B: OpenADR IF emits trigger only. Planner creates packet during replan.
  Either works, but must be consistent across all three locations.
```


### W-10: UC-13 DISPATCH_SETPOINT — Planner Creates Tracking Packet but Isn't Triggered [MINOR]

**Affected:** Step 5 UC-13

UC-13 says: "Planner creates synthetic EnergyPacket for override tracking" and
"PlanTrigger.CAPACITY_CHANGE". But DISPATCH_SETPOINT bypasses the Planner entirely
(goes direct to Dispatcher per Step 2). So the Planner doesn't run unless something
else triggers it.

```
Resolution needed: either Dispatcher creates the tracking packet (it owns the override
  session), or DISPATCH_SETPOINT emits PlanTrigger.CAPACITY_CHANGE to get the Planner
  to create the tracking packet and re-optimize around the constraint.
```


---

## 4. Design Gaps Introduced by Fixes

### W-11: RateHeuristic Entity — Referenced but Not Defined [DESIGN_GAP]

**Affected:** Step 4 §5 (Phase 1 step 3), Step 1

StaleRatePolicy.HEURISTIC_FORECAST references `RateHeuristic.predict(TimeOfDay, DayOfWeek)`.
But RateHeuristic is not defined anywhere in Step 1. It's analogous to AssetHeuristics
but for rate patterns.

```
Resolution needed: either
  A) Define RateHeuristic entity in Step 1 (DaytimeProfile, WeekdayWeights, SeasonalFactor
     applied to PastRates history — same structure as AssetHeuristics)
  B) Reuse existing AssetHeuristics pattern: create a virtual "rate" heuristic stored
     on VenController with the same learning mechanism as SITE_RESIDUAL.
```


### W-12: RateEstimated Flag — Not on PlanTimeSlot Entity [MINOR]

**Affected:** Step 4 §5, Step 1 §6.2

Phase 1 sets `slot.RateEstimated = true` for slots with missing rate data, but
PlanTimeSlot in Step 1 doesn't have this field.

```
Resolution needed: add to PlanTimeSlot:
  RateEstimated:     bool        // true if rate data was estimated (StaleRatePolicy),
                                 // false if from VTN event. Used for PlanWarning generation.
```


### W-13: Thermal TargetEnergy Recomputation — Not in Algorithm [DESIGN_GAP]

**Affected:** Step 4 §5, Step 1 §3.1.1

Step 1 §3.1.1 says TargetEnergy is recomputed each plan cycle using ThermalModelParams.
Step 2 §2.2 says "TargetEnergy is RECOMPUTED each plan cycle." UC-14 exercises this.

But Step 4 Phase 1 (Prepare) never mentions recomputing TargetEnergy for thermal packets.
It classifies packets and assets but doesn't update packet targets.

```
Resolution needed: add to Phase 1, before step 5 (Classify packets):
  For each packet P on a thermal asset with ThermalModelParams:
    P.TargetEnergy_kWh = ThermalModelParams.compute(
      currentTemp = Asset.State.Temperature_C,
      targetTemp = from UserRequest,
      outdoorForecast = ExternalDataSource.predict(horizon),
      efficiency = Asset.Profile.Efficiency
    )
  Also update Step 3 mutation table: TargetEnergy_kWh can be UPDATED by Planner
  (for thermal packets only).
```


---

## 5. Edge Cases

### W-14: Phase 6 Does Not Handle EXPORT_LIMIT_EXCEEDED [EDGE_CASE]

**Affected:** Step 4 §10, Step 1 §6.7

PenaltyCondition includes EXPORT_LIMIT_EXCEEDED but Phase 6 only handles
PEAK_DEMAND_EXCEEDED and ENERGY_BUDGET_EXCEEDED. If a PenaltyRule with condition
EXPORT_LIMIT_EXCEEDED exists, Phase 6 would skip it.

Phase 5 handles export capacity limits (curtails PV), but this is a hard limit,
not a penalty evaluation. A penalty for exceeding export limits (e.g. grid connection
agreement) would go unchecked.

```
Resolution needed: add EXPORT_LIMIT_EXCEEDED handling to Phase 6:
  PlannedPeakExport = max(S.PlannedExport_kW for all S in period)
  If PlannedPeakExport > Threshold → same avoidance logic as PEAK_DEMAND_EXCEEDED.
```


### W-15: V2G (Vehicle-to-Grid) Discharge — Deferred but Referenced [EDGE_CASE]

**Affected:** Step 1 §3.1, Step 4 §8

V2G is referenced in AssetProfile (Bidirectional=true for EV) and Phase 4 (Storage
assets include V2G-capable EV). But no design addresses the unique V2G constraints:
user sets minimum departure SoC, EV must have enough charge to drive. Battery discharge
freely; EV discharge requires departure awareness.

```
Status: deferred from V-23. Noted again for completeness.
  When addressed, needs: departure SoC constraint in AvailabilityWindows,
  discharge capped at (currentSoC - departureSoC) × capacity.
```


---

## Summary

| Severity | Count | IDs |
|---|---|---|
| CRITICAL | 3 | W-01, W-02, W-03 |
| DESIGN_GAP | 3 | W-04, W-11, W-13 |
| STALE | 2 | W-05, W-06 |
| EDGE_CASE | 2 | W-14, W-15 |
| MINOR | 5 | W-07, W-08, W-09, W-10, W-12 |
| **Total** | **15** | |

### Assessment

The three CRITICAL issues (W-01, W-02, W-03) are all consequences of the surplus-aware
pricing change — the surplus pool tracking was correctly added to Phase 3 but not fully
propagated to Phase 4, Phase 7, and the early firm-up check. These are mechanical fixes:
define a slot-level GridEffectiveCost for FLEXIBLE slots and storage comparisons, and add
`slotRemainingSurplus -= chargePower` to Phase 4.

The STALE issues (W-05, W-06) reflect that Step 3 hasn't been updated since Draft 4
while Steps 1, 2, and 4 have had significant additions. Step 3 needs a refresh pass.

The remaining issues are localization fixes (defaults, field additions, wording consistency).

No structural or architectural problems found. The core design — EnergyPackets with
ValueCurves, two-layer FIRM/FLEXIBLE planning, surplus-aware opportunity cost pricing,
MeasurementWindow-based penalty evaluation, and FlexibilityEnvelopes for VTN coordination
— is internally consistent and exercised by use cases.

---

*End of Step 6 (Draft 2, Pass 2). Fifteen issues cataloged, not solved.*
