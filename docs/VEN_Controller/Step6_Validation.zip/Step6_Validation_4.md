# Step 6 — Validation & Issue Identification (Pass 3): VEN Controller (HEMS)

**Scope:** Single-site residential Home Energy Management System acting as OpenADR 3.1 VEN.  
**Version:** Draft 3 (fresh pass after all Pass 1 + Pass 2 fixes applied)  
**Prerequisite:** Steps 1–5 (all at latest drafts)

---

## Overview

Third validation pass. All 30 issues from Pass 1 and 15 from Pass 2 have been resolved
(V-23/W-15 deferred: V2G). This pass finds only text-level consistency issues and
minor coverage gaps. No structural, architectural, or algorithmic problems remain.

```
Severity levels:
  STALE       — text contradicts changes made elsewhere
  MINOR       — naming, clarity, or consistency issue
  COVERAGE    — a defined capability has no use case exercising it
```

---

## 1. Text Consistency: GridEffectiveCost Propagation

The GridEffectiveCost field was introduced in Pass 2 (W-01) but not every textual
reference to "EffectiveCost" in FLEXIBLE/storage contexts was updated.

### X-01: Phase 4 SortedSlots Uses "EffectiveCost" [STALE]

**Affected:** Step 4 §8.1

```
Current:  SortedSlots = all FIRM slots sorted by EffectiveCost ascending
Should:   SortedSlots = all FIRM slots sorted by GridEffectiveCost ascending
```
Phase 4 has no per-packet context. The ProfitablePairs check was correctly
updated to GridEffectiveCost but the sort line was missed.


### X-02: Worked Example FLEXIBLE Slots Say "EffectiveCost" [STALE]

**Affected:** Step 4 §15 (worked example Phase 1)

```
Current:  EV's eligible FLEXIBLE slots (20:00-07:00) all have EffectiveCost = €0.148
Should:   EV's eligible FLEXIBLE slots (20:00-07:00) all have GridEffectiveCost = €0.148
```


### X-03: Hold Flexibility Heuristic Says "EffectiveCost" [STALE]

**Affected:** Step 4 §5.1

```
Current:  "All FLEXIBLE slots for a packet have similar EffectiveCost"
          "if a packet's eligible FLEXIBLE slots have ... similar EffectiveCost"
Should:   GridEffectiveCost in both places.
```


### X-04: FlexibilityEnvelope.EstimatedCost Comments [STALE]

**Affected:** Step 1 §6.9, Step 2 Post-Planning, Step 4 §11

All three say "average(eligible slot EffectiveCost)" for FLEXIBLE slots.
Should say "average(eligible slot GridEffectiveCost)" since FLEXIBLE slots
have no per-packet surplus-aware EffectiveCost.

```
Step 1 §6.9:  EstimatedCost_EUR: float  // EnergyNeeded × average(eligible slot EffectiveCost)
Step 2:       EstimatedCost = EnergyNeeded × avg(EffectiveCost for eligible FLEXIBLE slots)
Step 4 §11:   EstimatedCost = EnergyNeeded × avg(EffectiveCost for eligible FLEXIBLE slots)
```


---

## 2. Step 3 Residual Staleness

### X-05: Step 3 Field Mutation Table — TargetEnergy Mutability [STALE]

**Affected:** Step 3 §5 (field mutation table)

```
Current:  | TargetEnergy_kWh | CREATE | | |
Should:   | TargetEnergy_kWh | CREATE | UPDATE (thermal only) | |
```
The lifecycle table (§2.5) correctly shows Planner mutates TargetEnergy for
thermal packets. The field mutation table was not updated.


### X-06: Step 3 Fast Loop Missing Monitor Checks [STALE]

**Affected:** Step 3 §3.1 (fast loop procedural description)

The Monitor section at t=0.100s says:
```
  → checks penalty proximity
  → checks per-packet cost warnings
  → checks tier feasibility (IsOnTrack)
```

Missing from this procedural list (added in Step 2 §2.6 but not propagated to Step 3):
```
  → computes RollingAverage over MeasurementWindow for each PenaltyRule
  → checks LatestStart: PENDING packets past LatestStart → ABANDONED
  → checks StaleContinue: CONTINUE packets with no progress for StaleContinueTimeout → ABANDONED
```
The state machine (§5) was correctly updated. The procedural loop was not.


---

## 3. Minor Wording Issues

### X-07: Step 2 "Reject IMPLICIT" References Removed Enum [MINOR]

**Affected:** Step 2 §2.2 (translation logic step 1a)

```
Current:  "1a. Reject IMPLICIT: heuristic-driven assets (COOKING_STOVE, etc.) do NOT get..."
Issue:    IMPLICIT was removed from UserRequestMode in Step 1 §1.9.
Should:   "1a. Reject uncontrollable assets: heuristic-driven assets (COOKING_STOVE, etc.)..."
```


### X-08: ON_OFF Adjustability — No Algorithm Handling [MINOR]

**Affected:** Step 4 §7.2

STEPPED has explicit handling (select from PowerSteps). ON_OFF has none.
ON_OFF is functionally STEPPED with PowerSteps = [0, MaxPower] but this is not stated.

```
Add note to §7.2:
  "ON_OFF assets are treated as STEPPED with PowerSteps = [0, MaxPower_kW].
  The algorithm uses the same feasibleSteps logic — either full power or off."
```


---

## 4. Use Case Coverage Gaps

### X-09: No UC Exercises ASAP, ASAP_FREE, BY_DEADLINE_FREE, or MAX_COST Modes [COVERAGE]

**Affected:** Step 5

Four of six UserRequestMode values have no use case:
- ASAP: "charge now, cost-aware" (differs from BY_DEADLINE in having no deadline flexibility)
- ASAP_FREE: "charge now, only free energy"
- BY_DEADLINE_FREE: "charge by deadline, only free energy"
- MAX_COST: "charge whenever, just stay within budget"

These modes affect how the User Request Manager builds DeadlineTiers and ComfortRates.
No UC verifies the translation is correct.

```
Not blocking: the algorithm treats all packets the same once they're EnergyPackets.
The translation from mode → DeadlineTier is in Step 2 §2.2 but untested.
```


### X-10: No UC Exercises HEATER or GENERIC_* Asset Types [COVERAGE]

**Affected:** Step 5

HEATER is structurally identical to HEAT_PUMP (thermal, STEPPED/STEPLESS).
GENERIC_CONSUMER and GENERIC_PRODUCER are fallbacks. These are low-risk gaps
since UC-14 exercises the thermal model and UC-11 exercises a consumption-only site.


---

## Summary

All 10 issues resolved. X-09 and X-10 are acknowledged coverage gaps (no fix needed).

| ID | Severity | Status | Resolution |
|---|---|---|---|
| X-01 | STALE | ✅ FIXED | Phase 4 SortedSlots uses GridEffectiveCost (Step 4 §8.1) |
| X-02 | STALE | ✅ FIXED | Worked example FLEXIBLE slots say GridEffectiveCost (Step 4 §15) |
| X-03 | STALE | ✅ FIXED | Hold flexibility heuristic and Phase 1/2 comments use GridEffectiveCost (Step 4 §5, §5.1, §6) |
| X-04 | STALE | ✅ FIXED | Envelope EstimatedCost comments say GridEffectiveCost (Step 1 §6.9, Step 2 Post-Planning) |
| X-05 | STALE | ✅ FIXED | Step 3 mutation table: TargetEnergy = CREATE / UPDATE (thermal) (Step 3 §5) |
| X-06 | STALE | ✅ FIXED | Step 3 fast loop lists RollingAverage, LatestStart, StaleContinue checks (Step 3 §3.1) |
| X-07 | MINOR | ✅ FIXED | "Reject IMPLICIT" → "Reject uncontrollable assets" (Step 2 §2.2) |
| X-08 | MINOR | ✅ FIXED | ON_OFF documented as STEPPED with [0, MaxPower]. No separate code path. (Step 1 §1.2) |
| X-09 | COVERAGE | ℹ️ NOTED | ASAP, ASAP_FREE, BY_DEADLINE_FREE, MAX_COST modes untested. Low risk — algorithm is mode-agnostic once packets exist. |
| X-10 | COVERAGE | ℹ️ NOTED | HEATER, GENERIC_* untested. Low risk — structurally identical to tested types. |

---

*End of Step 6 (Draft 3, Pass 3). All issues resolved. Design is consistent.*

*The core design — EnergyPackets with ValueCurves, two-layer FIRM/FLEXIBLE planning,
surplus-aware opportunity cost pricing with GridEffectiveCost for slot-level comparisons,
MeasurementWindow-based penalty evaluation, and FlexibilityEnvelopes for VTN coordination
— is internally consistent across all six documents and exercised by 14 use cases.
Only V2G remains deferred.*
